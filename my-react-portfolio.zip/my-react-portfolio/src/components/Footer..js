

const Footer = () => {
    
    return (
        
      <footer className="container-fluid pt-4 bg-light"> 
        <p className="text-center">© copyright by : &hearts; © Rekha Kumari 2021</p>
      </footer>
    );
  };
  
  export default Footer;